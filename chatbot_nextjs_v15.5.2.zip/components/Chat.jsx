import { useState, useRef, useEffect } from 'react'
import useSWRMutation from 'swr/mutation'

async function triggerChat(url, { arg }) {
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ message: arg }),
  })
  if (!res.ok) throw new Error('Network error')
  return res.json()
}

export default function Chat() {
  const [input, setInput] = useState('')
  const [messages, setMessages] = useState([])
  const inputRef = useRef(null)
  const { trigger, isMutating } = useSWRMutation('/api/chat', triggerChat)

  useEffect(() => {
    inputRef.current?.focus()
  }, [])

  async function sendMessage(e) {
    e?.preventDefault()
    if (!input.trim()) return
    const userMsg = { role: 'user', text: input.trim() }
    setMessages(prev => [...prev, userMsg])
    const userInput = input.trim()
    setInput('')
    try {
      const data = await trigger(userInput)
      const botMsg = { role: 'bot', text: data.reply || 'No response' }
      setMessages(prev => [...prev, botMsg])
    } catch (err) {
      const errMsg = { role: 'bot', text: 'Error: ' + err.message }
      setMessages(prev => [...prev, errMsg])
    }
  }

  return (
    <div className="max-w-2xl mx-auto p-6">
      <div className="border rounded-lg p-4 h-96 overflow-y-auto mb-4 bg-white">
        {messages.length === 0 && <div className="text-gray-500">Say hi to the bot 👋</div>}
        {messages.map((m, i) => (
          <div key={i} className={m.role === 'user' ? 'text-right my-2' : 'text-left my-2'}>
            <div className={m.role === 'user' ? 'inline-block bg-blue-100 px-3 py-2 rounded-lg' : 'inline-block bg-gray-100 px-3 py-2 rounded-lg'}>
              {m.text}
            </div>
          </div>
        ))}
      </div>

      <form onSubmit={sendMessage} className="flex gap-2">
        <input
          ref={inputRef}
          value={input}
          onChange={e => setInput(e.target.value)}
          placeholder="Type a message..."
          className="flex-1 p-2 border rounded-lg"
        />
        <button type="submit" disabled={isMutating} className="px-4 py-2 bg-blue-600 text-white rounded-lg">
          {isMutating ? '...' : 'Send'}
        </button>
      </form>
    </div>
  )
}
