# Chatbot Next.js App

## What this is
A minimal Next.js (Pages Router) chatbot skeleton that uses a serverless API route to proxy requests to OpenAI.
- `pages/index.js` — UI
- `pages/api/chat.js` — server-side proxy that calls OpenAI (you must add your API key)
- `components/Chat.jsx` — chat UI component

## Setup
1. Install dependencies:
   ```
   npm install
   ```
2. Add your OpenAI API key to `.env.local`:
   ```
   OPENAI_API_KEY=sk-...
   ```
3. Run locally:
   ```
   npm run dev
   ```
4. Deploy on Vercel: set the environment variable `OPENAI_API_KEY` in your Vercel project settings and deploy.

## Important notes
- Do **not** commit your OpenAI API key to git.
- The server route `pages/api/chat.js` expects `POST` with JSON `{ "message": "Hello" }` and will return `{ "reply": "..." }`.
