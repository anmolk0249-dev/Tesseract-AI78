// pages/api/chat.js
// Simple serverless proxy to OpenAI's Chat completions.
// IMPORTANT: set OPENAI_API_KEY in your environment (Vercel, .env.local, etc.)
import fetch from 'node-fetch'

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST')
    return res.status(405).json({ error: 'Method not allowed' })
  }

  const { message } = req.body || {}
  if (!message || typeof message !== 'string') {
    return res.status(400).json({ error: 'Missing message' })
  }

  const apiKey = process.env.OPENAI_API_KEY
  if (!apiKey) {
    return res.status(500).json({ error: 'OpenAI API key not configured on server' })
  }

  try {
    // Call OpenAI Chat Completions (example using Chat Completions API)
    const payload = {
      model: 'gpt-4o-mini', // change if needed
      messages: [{ role: 'user', content: message }],
      max_tokens: 500,
    }

    const r = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`,
      },
      body: JSON.stringify(payload),
    })

    if (!r.ok) {
      const text = await r.text()
      return res.status(500).json({ error: 'OpenAI API error', details: text })
    }

    const data = await r.json()
    const reply = data?.choices?.[0]?.message?.content ?? ''
    return res.status(200).json({ reply })
  } catch (err) {
    return res.status(500).json({ error: err.message })
  }
}
