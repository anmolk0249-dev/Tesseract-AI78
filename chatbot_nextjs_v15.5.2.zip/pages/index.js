import Head from 'next/head'
import dynamic from 'next/dynamic'
const Chat = dynamic(() => import('../components/Chat'), { ssr: false })

export default function Home() {
  return (
    <>
      <Head>
        <title>Chatbot</title>
        <meta name="viewport" content="initial-scale=1.0, width=device-width" />
      </Head>
      <main style={{ padding: '20px', fontFamily: 'Arial, sans-serif', background: '#f3f4f6', minHeight: '100vh' }}>
        <h1 style={{ textAlign: 'center' }}>Chatbot</h1>
        <Chat />
      </main>
    </>
  )
}
